//
//  AppDelegate.swift
//  pip_swift
//
//  Created by 无夜之星辰 on 2021/5/26.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        // 【社区补丁 2026-10-18】启动速度拉满：首屏关键路径只保留轻量 UserDefaults/内存操作；
        // 磁盘清理、视频缓存预热、快捷指令预热全部挪出 didFinishLaunching 同步路径，
        // 定位授权弹窗也延迟到首帧之后，不阻塞启动。
        DiagnosticsResetManager.resetDiagnosticsIfBuildChanged()
        DiagnosticsResetManager.clearDiagnosticsIfDebugModeDisabled()
        AppDebugLogger.registerBackgroundFlush()
        KeepAliveModeText.migrateDefaultToLowPowerPiPIfNeeded()
        LightweightRuntimeDiagnostics.start()
        KeepAliveNotificationTester.sanitizeOnLaunch()
        DispatchQueue.main.async {
            AppDebugLogger.trimOnLaunch()
            CacheCleanupManager.cleanOnLaunch()
            GeneratedPiPVideoCache.prepareForLaunch()
            PiPShortcutRuntimeRegistration.warmUpProviderIfAvailable()
            // 【社区补丁 2026-10-11】定位保活：首帧后触发一次始终允许授权弹窗
            LocationKeepAlive.shared.ensurePermission()
        }
        if AppDebugLogger.isDebugModeEnabled {
            DiagnosticsRuntimeState.startAppStateTracking()
            DiagnosticsRuntimeState.refreshAppState()
            MetricKitLogger.shared.start()
            DebugDiagnosticsMonitor.setEnabled(true)
            ProcessTerminationDiagnostics.prepareForLaunch()
        }
        return true
    }

    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        PiPShortcutActionCenter.request(from: url)
    }
    
    // MARK: UISceneSession Lifecycle
    
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    
}
