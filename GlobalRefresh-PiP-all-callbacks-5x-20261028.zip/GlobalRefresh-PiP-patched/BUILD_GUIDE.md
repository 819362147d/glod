# 云端构建指南（Codemagic）

目标：把打好社区补丁的源码在云端 Mac 上编译成**未签名 IPA**，
下载后用你自己的 Apple ID 自签安装。

全程不需要你有 Mac，构建本身在 Codemagic 的免费额度内一般够用
（免费账号每月有一定构建分钟数，一个 Release 包约 10～20 分钟）。

## 步骤 1：把源码传到你自己的 GitHub

1. 在 GitHub 新建一个**私有**仓库（Private），名字随意，如 `globalrefresh-patched`。
2. 把本文件夹的全部内容（`pip_swift/`、`codemagic.yaml`、`PATCH_NOTES.md` 等）
   上传到这个仓库。可以用网页上传，也可以用 git：
   ```
   git init
   git add .
   git commit -m "patched 1.1.1"
   git branch -M main
   git remote add origin https://github.com/<你的用户名>/globalrefresh-patched.git
   git push -u origin main
   ```
   注意：不要把 `.git` 文件夹传上去（传的是工作区文件）。

## 步骤 2：Codemagic 添加应用

1. 打开 https://codemagic.io/start 注册/登录（可用 GitHub 账号直接登录）。
2. 点 **Add application**，选 **GitHub**，授权后选中你刚建的仓库。
3. Project type 选 **iOS App**。

## 步骤 3：开始构建

1. 进入应用页，Codemagic 会自动识别根目录的 `codemagic.yaml`。
2. 在 workflow 下拉框里选 **iOS unsigned IPA (community patched)**。
3. 点 **Start new build**，等待构建完成（约 10～20 分钟）。
4. 构建成功后，在 Artifacts 里下载
   `GlobalRefresh_1.1.1_patched_unsigned.ipa`。
5. 日志里会打印 SHA-256，可对照确认文件完整。

## 步骤 4：自签安装（仍需这一步）

未签名 IPA 不能直接装。用以下任一方式自签：

- **牛蛙助手**（微信小程序，手机上直接操作，最省事）
- **AltStore / Sideloadly**（电脑操作）

用你自己的 Apple ID 签。免费账号签出的应用 7 天过期需重签；
装好后去 iPhone「设置 → 通用 → VPN 与设备管理」信任开发者。

## 如果构建失败

1. 先看 Codemagic 的构建日志，定位报错行。
2. 常见原因：
   - `pod install` 失败：Codemagic 换 Xcode 镜像后偶发，重跑一次即可；
   - Swift 编译错误：把报错截图发给我，我修补丁；
   - 超时：`max_build_duration` 在 `codemagic.yaml` 里可调大。
3. 注意：构建成功 ≠ 真机验证过。补丁逻辑（尤其是版本门禁和熔断）
   建议在备用机或确认当前 iOS 版本 ≤ 26 的设备上先试。

## 费用说明

- Codemagic 免费额度用完后按分钟计费，单次构建约十几分钟，
  花不了多少钱；不想花钱就等下个月额度刷新。
- 全程不产生 Apple 开发者年费（自签用免费 Apple ID 即可）。
